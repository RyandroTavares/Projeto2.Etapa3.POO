import { PrismaClient } from "@prisma/client"
import axios from 'axios'

interface GitHubProps { 
    id: number
    login: string
    avatar_url: string
    html_url: string
    location: string
    repos_url: string
    bio: string
}

const prisma = new PrismaClient()

const setData = async () => {
    const response = await axios.get<GitHubProps>('https://api.github.com/users/EmanuelBacalhau')
    const data = response.data

    const prismaData = {
        gitHubId: data.id.toString(),
        login: data.login,
        avatarUrl: data.avatar_url,
        repositoryUrl: data.repos_url,
        reposUrl: data.repos_url,
        location: data.location,
        bio: data.bio
    }
    const result = await prisma.gitHub.create({data: prismaData})
    console.log(result);
}

setData()